import os, pathlib, shutil

# change captures_folder to your Captures folder directory
captures_folder = 'E:/Captures'

src = f"{os.environ['LOCALAPPDATA']}/Temp"
for video in [f for f in os.listdir(src) if pathlib.Path(f).suffix == '.mp4']:
    shutil.move(f"{src}/{video}", f'{captures_folder}/{video}')
quit()